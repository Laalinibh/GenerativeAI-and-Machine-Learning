from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from src.LoadLLM import LoadLLM
from src.logger_utils import Logger
from src.source_data import InputRequest

import uvicorn
import logging

app = FastAPI()
origins = ["*"]

logger = Logger()
logging = logger.get_logger()


app = FastAPI()
origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

local_llm = LoadLLM()

@app.get("/")
async def check_service():
    """
    Checking if service is up and running
    :return:
    """
    logging.info("Checking if service is up and running")
    return {"status": 200, "message": "Service is up and running"}


@app.get("/llm_models")
async def loaded_models():
    """
    Getting list of loaded models
    :return:
    """
    try:
        logging.info("Getting list of loaded models")
        models = local_llm.get_all_models()

        logging.info("Successfully retrieved list of loaded models")
        return {"status": 200, "message": "success", "models": models}
    except Exception as ex:
        logging.error(f"Error getting list of loaded models: {ex}")
    return {"status": 400, "message": f"Error getting list of loaded models: {ex}"}

@app.post("/llm_task")
async def llm_output(request: InputRequest):
    """
    Getting LLM output
    :param reqest:
    :return:
    """
    try:
        logging.info("Getting LLM output")
        output = local_llm.get_output(request)
        logging.info("Successfully retrieved LLM output")
        return {"status": 200, "message":"success","output": output}
    except Exception as ex:
        logging.error(f"Error getting LLM output: {ex}")
        return {"status": 400, "message": f"Error getting LLM output {ex}"}



if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, workers=1)