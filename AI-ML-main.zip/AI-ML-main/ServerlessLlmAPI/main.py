import gradio as gr

from src.LoadLLM import LoadLLM
from src.logger_utils import Logger

logger = Logger()
logging = logger.get_logger()

llm_model = LoadLLM()
#list_models = llm_model.get_all_models()

gr.close_all()
with gr.Blocks() as demo:
    logging.info("Entered the demo")
    gr.Markdown("# LLM with Gradio")
    template = gr.Textbox(label="template",info="Input Prompt to generate the text", show_copy_button=True, lines=5)

    with gr.Row():
        with gr.Column():
            model_name = gr.Dropdown(llm_model.get_all_models()+['Other'], label="Select available options",
                                     info="For new models select Other or please Update github code & redeploy to update models")
        with gr.Column():
            other_model_name = gr.Textbox(label="Enter model name", show_copy_button=True,
                                          info="If you only select Other then                           "\
                                               "Enter the Huggingface models like meta-llama/Llama-2-7b, "\
                                               "mistralai/Mistral-7B-v0.1, etc", lines=1)

    btn = gr.Button("Submit") #Submit button side by side!
    with gr.Accordion("Advanced options", open=False): #Let's hide the advanced options!
            with gr.Row():
                with gr.Column():
                    max_tokens = gr.Slider(label="max_length", minimum=0, maximum=1024, value=256,
                                           info="Max output tokens or words to generate")
                    temperature = gr.Slider(label="temperature", minimum=0.00, maximum=0.99, value=0.2,
                                            info="Temperature to experiment with based on creativity")
                    top_k = gr.Slider(label="top_k", minimum=0, maximum=512, value=50,
                                      info="Enter last k words to give attention while predicting current word. "\
                                      "Top-K sampling involves sorting the probability distribution and selecting "
                                      "the top-K most likely candidates. By adjusting the value of K, you can control "\
                                      "the diversity of the generated text. A smaller K results in more deterministic and focused outputs, "\
                                      "while a larger K introduces more randomness.")

                    num_beams = gr.Number(label="num_beams",
                                          minimum=0, maximum=5,
                                          value=1,
                                          info="Number of beams for beam search. "\
                                               "Default is 1 shouldn't be less than that." )
                with gr.Column():
                    max_new_tokens = gr.Slider(label="max_new_tokens", minimum=0, maximum=1024, value=256,
                                               info="Max new tokens you want to generate")
                    repeat_penalty = gr.Slider(label="repeat_penalty", minimum=0.00, maximum=5.0, value=1.1,
                                               info="Enter repeat penatlity")
                    top_p = gr.Slider(label="top_p", minimum=0.00, maximum=1.0, value=0.2,
                                      info="Adjusting the value of  p allows you to control the diversity of the "\
                                      "generated text. A smaller p results in more deterministic and focused outputs, "\
                                      "while a larger p introduces more randomness.")
                    # num_return_sequences = gr.Number(label="num_return_sequences", minimum=1, maximum=10, value=1,
                    #                                  info="Number of top output to return")
            with gr.Row():
                stop_words = gr.Textbox(label="stop words", info="Please enter as list example to stop at strings 'Keywords:' and '####' : ['Keywords:', '####'] "\
                                                                 "Currently this is not working ignore need to address stopping_criteria")


    output = gr.Textbox(label="Generated text") #Move the output up too

    btn.click(fn=llm_model.get_output,
              inputs=[template,
                      model_name,
                      other_model_name,
                      max_tokens,
                      max_new_tokens,
                      temperature,
                      top_k,
                      top_p,
                      repeat_penalty,
                      num_beams],
              outputs=[output])



gr.close_all()
demo.launch(share=False, server_port=8181)