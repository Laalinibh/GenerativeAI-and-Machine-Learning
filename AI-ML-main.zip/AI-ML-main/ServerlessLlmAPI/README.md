<h2>REST-API/Gradio API</h2>

<h3>Assumption</h3>
<ul>
    <li><b>Prompt Optimization</b>: Currently there isn't any idle prompt, results would vary from prompt to prompt which we need to experiment ad get best prompt for our use case</li>
    <li>Choose the <b>LLM model</b> as per the <b>resources available</b></li>
    <li>Give required input & <b>model parameters</b> like:</li>
        <ul>
            <li>Temperature</li>
            <li>max_length</li>
            <li>num_beams(Beam search)</li>
            <li>Top-k</li>
            <li>Top-p</li>
            <li>etc</li>
        </ul>
    <li>We don't have any <b>Evaluation metrics</b> for LLMs like:</li>
        <ul>
            <li>Accuracy</li>
            <li>F1-score</li>
            <li>Precision</li>
            <li>Recall</li>
            <li>Belu score</li>
            <li>Cosine Similarity</li>
            <li>Etc</li>
            <li>Varies for model you use.</li>
        </ul>
    <li>Would <b>Fail badly</b> for <b>domains</b> where they <b>data is private</b> and <b>isn't available</b> in <b>public platforms</b></li>
        <ul>
            <li>Healthcare</li>
            <li>Finance</li>
            <li>etc</li>
        </ul>
</ul>

<h3>Instructions</h3>
<ul>
    <li>Modify the ports you have 8181 as per requirements in main.py</li>
    <li>If you want to use <b>public endpoint</b> in <b>main.py</b> modify <b>demo.launch(share=True, port=8000)</b></li>
    <li><b>Fast-API</b> app.py</li>
        <ul>
            <li>Please feel free to <b>update port</b> as per the <b>availability</b>.</li>
        </ul>
    <li>Please update packages in <b>requirements.txt</b> as per the <b>GPUs & it's cuda version</b></li>
    <li>Please feel free to add <b>more model parameters</b> in <b>Advanced Options</b></li>
    <li>I have currently fixed to <b>7-8</b> of them</li>
</ul>

<h3>Setup & installation or deployment</h3>
<ul>
    <li>Installing packages: <b>pip install -r requirements.txt</b></li>
    <li><b>Gradio</b>: python3 main.py</li>
    <li><b>Fast-API</b>: python3 app.py</li>
        <ul>
            <li>If <b>port is 8000</b> in local: <b>http://localhost:8000/docs</b> you can access all endpoints and default inputs.</li>
        </ul>
    <li>Add Dockerfile & docker-compose as per the requirements</li>
</ul>

Reasons for FastAPI: 
<ul>
    <li>The sdk available for banana.dev in <b><a href="https://docs.banana.dev/banana-docs/core-concepts/sdks/python">python</a></b><br>
</li>
    <li>Even can be <b>re-used</b> for <b>any provider(<a href="https://fullstackdeeplearning.com/cloud-gpus/">link</a>)</b> where <b>API KEY</b> is required.</li>
    <li>Few of them even they offer <b>GPU for low cost</b> the <b>documentation</b> is very <b>limited</b>.</li>
    <li>No demo videos or resource, etc</li>
</ul>

<h3>Future</h3>
<ul>
    <li>Please feel free to deploy <b>REST-API</b> in <b>Serverless Instance</b>.</li>
    <li>Use <b>gradio in local</b> as take inputs along with <b>API KEY</b></li>
        <ul>
            <li>URL or endpoint of instance</li>
            <li>API KEY</li>
            <li>Required inputs</li>
            <li>ETC</li>
        </ul>
    <li>Configure Gradio in local as per the inputs like:</li>
        <ul>
            <li>Videos</li>
            <li>Audios</li>
            <li>Images</li>
            <li>Text</li>
            <li>etc</li>
        </ul>
    <li>Retrieve the output in Gradio</li>
    <li>Any <b>QA or available resource</b> can test and <b>API KEY</b> can be <b>updated or deprecated</b> once the <b>task is completed</b>.</li>
    <li>If it's <b>hosted in GPU communicate</b> with the <b>team</b> for which <b>model</b> to use, else you would be <b>wasting 2-3+ minutes everytime</b> for the <b>model to load</b>.</li>
    
</ul>
