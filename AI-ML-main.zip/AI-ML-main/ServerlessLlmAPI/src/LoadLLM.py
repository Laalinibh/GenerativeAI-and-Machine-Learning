"""
loading the model and generating the output
"""
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline

import torch

import gc
from src.logger_utils import Logger
from src.source_data import InputRequest

logger = Logger()
logging = logger.get_logger()

model_info = None


# global model_info

class LoadLLM:
    """
    loading LLM model and creating pipeline
    please make it generic in UI if possible for Model as well
    """
    model = None
    tokenizer = None
    pipe = None
    model_name = None
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    all_models = ['gpt2', 'gpt2-medium', 'gpt2-large']

    def __init__(self, model_name="gpt2"):
        """
        loading the model & creating pipeline
        please make it generic in UI if possible for Model as well
        So manually updated of the code can be avoided
        :param model_name:
        """
        try:
            self.model_name = model_name
            if self.model_name is not None:
                self.load_model()
            else:
                return
            if self.model is not None:
                self.load_tokenizer()
            else:
                return
            if self.tokenizer is not None:
                self.load_pipeline()
            else:
                return
        except Exception as ex:
            logging.error(f"Error while assigning model name or id: {ex}")
        return

    def get_model_name(self):
        """"Returns model name"""
        try:
            return self.model_name
        except Exception as ex:
            logging.error(f"Error while getting model name: {ex}")
        return

    def load_model(self):
        """Loads a model from Hugging Face"""
        try:
            # can comment off load_in_4bit & quantization_config to enable 4 bit conversion
            # bnb_config = BitsAndBytesConfig(
            #     load_in_4bit=True,
            #     bnb_4bit_quant_type="nf4",
            #     bnb_4bit_use_double_quant=True,
            # )

            # if device_map doesn't work'
            # check nvidia-smi for gpu, check versions compatibility logs & etc post that it still doesn't work
            # use the below code to move to GPU and run the model
            # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            # AutoModelForCausalLM.from_pretrained(self.model_name).to_device(device) add the required parameters

            # enable torch_dtype
            # for mixed precision would reduce accuracy as well
            self.model = AutoModelForCausalLM.from_pretrained(self.model_name,
                                                              # torch_dtype=torch.bfloat16,
                                                              device_map="auto",
                                                              # enable the below to load the compressed model acuracy will be reduced
                                                              # load_in_4bit=True,
                                                              # quantization_config=bnb_config,
                                                              )

            logging.info("Successfully loaded the model")
        except Exception as ex:
            logging.error(f"Error while loading model: {ex}")

    def load_tokenizer(self):
        """Loads the tokenizer from the Hugging Face"""
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            logging.info("Successfully loaded the tokenizer")
        except Exception as ex:
            logging.error(f"Error while loading tokenizer: {ex}")

    def load_pipeline(self):
        """
        Create a pipeline using model and tokenizer
        In future versions please make the task also generic need not be text-generation only
        all possible tasks can be found here as per the model: https://huggingface.co/docs/transformers/main_classes/pipelines
        """
        try:
            if self.model is not None and self.tokenizer is not None:
                self.pipe = pipeline("text-generation",
                                     model=self.model,
                                     tokenizer=self.tokenizer,
                                     # enable this for mixed precision
                                     # torch_dtype=torch.bfloat16,

                                     device_map="auto")
                logging.info("Successfully loaded the pipeline")
            else:
                logging.error("Model or tokenizer not loaded")
        except Exception as ex:
            logging.error(f"Error while loading the pipeline: {ex}")

    def get_pipeline(self):
        """:return: pipeline"""
        return self.pipe

    def get_tokenizer(self):
        """:return: tokenizer"""
        return self.tokenizer

    def get_model(self):
        """:return: model"""
        return self.model

    def get_all_models(self):
        return self.all_models

    def get_output(self,
                   prompt,
                   model_name="gpt2",
                   other_model_name="gpt2",
                   max_length=256,
                   max_new_tokens=256,
                   temperature=0.2,
                   top_k=40,
                   top_p=0.2,
                   repetition_penalty=1.1,
                   num_beams=1,
                   num_return_sequences=1,
                   no_repeat_ngram_size=0,
                   stop_sequence=None,
                   do_sample=True,
                   low_memory=True):
        """

        :param prompt: Input prompt to the LLM
        :param model_name: model selected from given options
        :type other_model_name: loading new model added to the list
        :param max_length: Max number of words to generate
        :param max_new_tokens:
        :param temperature: How much creativity to add, less temperature would avoid uncertainty
        :param top_k: Top number of words to consider when generating new tokens
        :param top_p:
        :param repetition_penalty:
        :param num_beams: beam search
        :param no_repeat_ngram_size:
        :param num_return_sequences:
        :param stop_sequence:
        :param do_sample:
        :param low_memory:
        :return:
        """
        try:
            logging.info("Generation output")
            stop_seq = None

            if type(prompt)!=str and type(prompt)==InputRequest:
                model_name = prompt.model_name
                other_model_name = prompt.other_model_name
                max_length = prompt.max_length
                max_new_tokens = prompt.max_new_tokens
                temperature = prompt.temperature
                top_k = prompt.top_k
                top_p = prompt.top_p
                repetition_penalty = prompt.repetition_penalty
                num_beams = prompt.num_beams
                prompt = prompt.prompt

            # checking if they want to load some new model
            if self.model_name != model_name:
                if (model_name=="other" and other_model_name is not None
                        and type(other_model_name) == str and len(other_model_name.strip())> 0):
                    model_name = other_model_name
                if model_name != self.model_name:
                    self.model_name = model_name
                    del self.pipe, self.model, self.tokenizer
                    gc.collect()
                    self.model, self.tokenizer, self.pipe = None, None, None
                    if self.device == 'cuda':
                        torch.cuda.empty_cache()
                    self.load_model()
                    self.load_tokenizer()
                    self.load_pipeline()
                    if self.pipe is None:
                        self.model_name = ""
                    else:
                        logging.info(f"Successfully loaded new model: {self.model_name}")
                    # elif model_name not in self.all_models:
                    #     self.all_models.append(model_name)
            if self.model is None:
                return "Error while loading model, please fix your code"
            if self.tokenizer is None:
                return "Error while loading tokenizer, please fix your code"
            if self.pipe is None:
                return "Error while loading pipeline, please fix your code"
            num_beams = int(num_beams)

            # Disabling this logic stop sequence or stopping_criteria generation isn't working need to addressed
            # Once fixed please enable the below logic

            # if stop_sequence is not None and type(stop_sequence) == list and len(stop_sequence) > 0:
            #     text_encodings = []
            #     for word in stop_sequence:
            #         if type(word) == str:
            #             words = word.strip().split()
            #             if len(words) == 1 and len(words[0].strip()) > 0:
            #                 text_encodings.append([words[0].strip()])
            #             elif len(words) > 1:
            #                 for w in words:
            #                     w = w.strip()
            #                     if len(w) > 0:
            #                         text_encodings.append([w])
            #
            #
            #     if len(text_encodings) > 0:
            #         stop_seq = self.tokenizer(text_encodings,
            #                              padding="max_length", is_split_into_words=True, truncation=True,
            #                              return_tensors="pt")

            output = self.pipe(prompt, num_beams=num_beams,
                               do_sample=do_sample,
                               max_length=max_length,
                               max_new_tokens=max_new_tokens,
                               temperature=temperature,
                               top_k=top_k,
                               top_p=top_p,
                               repetition_penalty=repetition_penalty,
                               no_repeat_ngram_size=no_repeat_ngram_size,
                               # fix the stop_sequence to stoping_criteria so it would stop post that tokens.
                               #                       stop_sequence = stop_seq,
                               num_return_sequences=num_return_sequences,
                               low_memory=low_memory)
            if output:
                output = output[0]["generated_text"]
                # temp = ""
                # for index, value in enumerate(output):
                #     temp += f"Prompt Output: {index+1}\n{value}\n\n\n"
                # output = temp.strip()
            logging.info("Successfully returning output")
            return output
        except Exception as ex:
            logging.error(f"Error while running llm: {ex}")
            return f"Error while running llm: {ex}"
