from pydantic import BaseModel, Field

class InputRequest(BaseModel):
    """
    input Request object
    """
    prompt:str = Field("New Delhi is the Capital of")
    model_name:str = Field("gpt2")
    other_model_name:str = Field("")
    max_length:int = Field(256)
    max_new_tokens:int = Field(256)
    temperature:float = Field(0.2)
    top_k:int = Field(50)
    top_p:float = Field(0.3)
    repetition_penalty:float = Field(1.1)
    num_beams:int = Field(1)
    # no_repeat_ngram_size:int = Field(0)
    # num_return_sequences:int = Field(1)
    # stop_sequence:str = Field(None)

