"""
hugging face connection using langchain
reference : https://cobusgreyling.medium.com/langchain-creating-large-language-model-llm-applications-via-huggingface-192423883a74
"""

import os
import time
from langchain import PromptTemplate, HuggingFaceHub, LLMChain


# please update your huggingface api token
os.environ['HUGGINGFACEHUB_API_TOKEN'] = '****'


# please feel free to fine-tune template
template = """Question: {question}

Answer: Let's think step by step."""

# working
# https://huggingface.co/google/flan-t5-base
model_name = "google/flan-t5-base"

#not wroking, it isn't support large models
# https://huggingface.co/google/flan-t5-large
# model_name = "google/flan-t5-large"

#https://huggingface.co/google/flan-t5-xl
# model_name = "google/flan-t5-xl"

#https://huggingface.co/decapoda-research/llama-7b-hf
# model_name = "llama-7b-hf"

#https://huggingface.co/tiiuae/falcon-40b
# model_name = "tiiuae/falcon-40b"

try:

    prompt = PromptTemplate(template=template, input_variables=["question"])
    llm_chain = LLMChain(prompt=prompt,
                         llm=HuggingFaceHub(repo_id=model_name,
                                            model_kwargs={"temperature":0,
                                                          "max_length":64}))

    start = time.time()
    question = "What is the capital of France?"
    output = llm_chain.run(question)
    print(output)
    print(time.time()-start)
except Exception as ex:
    print(ex)

