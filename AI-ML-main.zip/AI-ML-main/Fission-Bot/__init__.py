"""
please update this whenever website has new urls
"""
DEFAULT_OUTPUT = {"status":"200","message":"success", "sessionId": None, "question": None,"answer": "Not Found",
                  "prompts": [], "confidence":1.0, "source_url": "N/A", "source":None, "timestamp": None}
