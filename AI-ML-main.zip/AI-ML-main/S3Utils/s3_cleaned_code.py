"""
connecting to s3 and uploading instance
"""

import boto3
import os
from __init__ import ACCESS_KEY, SECRET_KEY, REGION, BUCKET_NAME


class S3AccessCode(object):
    client = None
    bucket = None
    all_paths = []

    def client_connection(self, ACCESS_KEY, SECRET_KEY, REGION_NAME):
        """
        connecting to s3 while creating the class instance
        :param ACCESS_KEY:
        :param SECRET_KEY:
        :param REGION_NAME:
        :return:
        """
        try:
            self.client = None
            self.client = boto3.resource(
                's3',
                aws_access_key_id=ACCESS_KEY,
                aws_secret_access_key=SECRET_KEY,
                region_name=REGION_NAME)
            print("Successfully connected to s3")
        except Exception as ex:
            print("Error while connecting to s3: ", ex)
        return None

    def connect_bucket(self, bucket_name):
        """
        conneting to the bucket
        :param bucket_name: appropriate bucket which we are accessing
        :return:
        """
        try:
            self.bucket = self.client.Bucket(bucket_name)
            print(f"Sucessfully connected to bucket : {bucket_name}")
        except Exception as ex:
            print(f"Error while connecting to bucket :{bucket_name}, error: {ex}")

    def upload_file(self, local_path, s3_path):
        """
        uploading file to s3
        :param local_path:
        :param upload_path:
        :return:
        """
        try:
            if self.bucket is None or self.client is None:
                print("check the s3/bucket connection as bucket or client connection has failed")
                return
            if local_path and s3_path:
                self.bucket.upload_file(local_path, s3_path)
        except Exception as ex:
            print(f"Error while uploading file({local_path}) to s3({s3_path}), error: {ex}")

    def upload_directory(self, local_path, s3_path):
        """
        uploading entire directory and subdirectories to s3
        :param local_path:
        :param s3_path:
        :return:
        """
        try:
            if self.bucket is None or self.client is None:
                print("check the s3/bucket connection as bucket or client connection has failed")
                return
            # if local_path and s3_path:
            #     self.bucket.upload_file(local_path, s3_path)
            if local_path and s3_path:
                # if here are any subdirectories iterating and uploading in the same order
                for subdir, dirs, files in os.walk(local_path):
                    for file in files:
                        full_path = os.path.join(subdir, file)
                        with open(full_path, 'rb') as data:
                            upload_path = s3_path + "/" + full_path[len(local_path) + 1:]
                            self.bucket.put_object(Key=upload_path, Body=data)
        except Exception as ex:
            print(f"Error while uploading file({local_path}) to s3({s3_path}), error: {ex}")

    def download_file(self, local_name, s3_file_path):
        """
        download a single s3 file from appropriate path
        :param local_name:
        :param s3_name:
        :return:
        """
        try:
            if self.bucket is not None:
                print("Please connect to the bucket before downloading the data")
                return
            if s3_file_path and local_name:
                self.bucket.download_file(s3_file_path, local_name)
            print(f"Successfully downloaded the file {local_name} from s3")
        except Exception as ex:
            print(f"Error downloading the file from s3({s3_file_path}) to local({local_name}): {ex}")

    def get_paths(self, s3_directory_path):
        """
        accesing the file paths witihin the directory
        :param s3_directory_path:
        :return:
        """
        try:
            self.all_paths = []
            if self.bucket is None:
                print("bucket is None")
                return []
            for file in self.bucket.objects.filter(Prefix=s3_directory_path):
                self.all_paths.append(file.key)
        except Exception as ex:
            print(f"Error accessing filenames from s3 path({s3_directory_path}) : {ex}")

    def get_path_dictonary(self, s3_directory_path):
        """
        s3_directory_path
        :param s3_directory_path:
        :return:
        """
        try:
            directory_keys = dict()
            self.get_paths(s3_directory_path)
            for curr_path in self.all_paths:
                x = curr_path.split("/")
                i = 0
                curr_dict = directory_keys
                while i < len(x) - 1:
                    if len(x[i]) > 0:
                        if x[i] in curr_dict:
                            curr_dict = curr_dict[x[i]]
                        else:
                            curr_dict[x[i]] = dict()
                    i += 1
            return directory_keys
        except Exception as ex:
            print(f"Error while extracting dicionaries : {ex}")

        return dict()

    def create_directory(self, directory_dict, path):
        """
        creating paths/directories wrt your local similiar to s3
        :param directory_dict:
        :param path:
        :return:
        """
        try:
            if directory_dict:
                for key, val in directory_dict.items():
                    new_path = path + "/" + key
                    os.mkdir(new_path)
                    self.create_directory(val, new_path)
        except Exception as ex:
            print(f"Error while creating directory : {ex}")

        # directory_dict = self.get_path_dictonary(path)

    def download_directory(self, local_directory, s3_directory_path):
        """
        Download a directory from s3 to local
        :param local_directory:
        :param s3_directory_path:
        :return:
        """
        try:
            directory_dict = self.get_path_dictonary(s3_directory_path)
            self.create_directory(directory_dict, local_directory)
            for s3_path in self.all_paths:
                self.bucket.download_file(s3_path, local_directory + "/" + s3_path)
            print("Successfully downloaded all the files from s3")
        except Exception as ex:
            print(f"Error downloading data from s3 path({s3_directory_path}) the local path({local_directory}) : {ex}")

    def get_all_downloaded_paths(self):
        """
        Downloaded data paths from s3
        :return:
        """
        try:
            if self.all_paths:
                return self.all_paths
        except Exception as ex:
            print(f"Error while downloading accessing all paths wrt s3:{ex}")
        return []


if __name__ == "__main__":
    s3_connection = S3AccessCode()

    # please upload the data in __init__.py
    s3_connection.client_connection(ACCESS_KEY, SECRET_KEY, REGION)
    s3_connection.connect_bucket(BUCKET_NAME)

    # Downloading the data from appropriate directory
    s3_connection.download_directory("s3_download", "parquet_check")

    # Uploading into appropriate path with new folder name parquet_upload_test
    s3_connection.upload_directory("parquet_check", "parquet_upload_test")
