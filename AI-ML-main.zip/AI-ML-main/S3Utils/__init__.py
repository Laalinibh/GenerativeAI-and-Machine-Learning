"""
loading configurations
"""
ACCESS_KEY = "****"
SECRET_KEY = "****"
REGION = "***"
BUCKET_NAME = "***"
