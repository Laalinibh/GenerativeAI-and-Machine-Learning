from datetime import datetime
from langchain.text_splitter import SpacyTextSplitter
from langchain.document_loaders import WebBaseLoader, url_selenium, unstructured

import re
import uuid
import PyPDF2

from logger_utils import Logger

logger = Logger()
logging = logger.get_logger()


class PreProcessData:
    """
    Chunking and tokenization of data
    """
    web_data = False
    file_name = None
    data = []

    def __init__(self, chunk_size=4098, chunk_overlap=256, text=""):
        try:
            # self.web_data = False
            self.text_splitter = SpacyTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
            )
            if len(text)>0:
                self.data = [text]
            logging.info("Successfully initialized PreProcessData")
        except Exception as ex:
            logging.error(f"Error while initializing PreProcessData: {ex}")

    def load_custom_data(self, text):
        self.file_name = None
        self.web_data = False
        try:
            self.data = [text]
            logging.info("Successfully loaded text data")
        except Exception as ex:
            logging.error(f"Error while loading text data: {ex}")

    def load_web_data(self, urls):
        self.file_name = None
        self.web_data = False
        try:
            loader = url_selenium.SeleniumURLLoader(urls=urls)
            self.data = loader.load()
            self.web_data = True
            logging.info("Successfully loaded web data")
            return True
        except Exception as ex:
            logging.error(f"Error while loading web data: {ex}")
        return False

    def load_pdf_data(self, file_name):
        self.file_name = None
        self.web_data = False
        try:
            pdf_reader = PyPDF2.PdfReader(file_name)
            text_content = ''
            for page in pdf_reader.pages:
                text_content += page.extract_text()
            self.data = [text_content]
            self.file_name = file_name
            logging.info("Successfully loaded pdf data")
        except Exception as ex:
            logging.error(f"Error while loading pdf data: {ex}")

    def load_text(self, file_name):
        self.file_name = None
        self.web_data = False
        try:
            text_data = ""
            with open(file_name, "r") as f:
                text_data = f.read()
            self.data = [text_data]
            self.file_name = file_name
            logging.info("Successfully loaded text data")
        except Exception as ex:
            logging.error(f"Error while loading text data: {ex}")

    def get_unique_hash(self):
        """
        trying to create unique hash for each document
        """
        try:
            # now = datetime.now()
            # current_time = now.strftime("%Y-%m-%d %H:%M:%S.%f")
            # return str(hash(current_time))
            uuid_str = str(uuid.uuid4())
            logging.info("Successfully created unique hash")
            return uuid_str
        except Exception as ex:
            logging.error(f"Error while creating unique hash: {ex}")
        return None

    def cleaning_data(self):
        """
        please add embedding to the output file
        """
        if self.data is None:
            logging.info(f"Load data for cleaning the data")
            return []
        self.docs = []
        try:
            for document in self.data:
                # cleaning text
                content = ""
                metadata = {"language": "en_us", "source": "Not available", "title": "Not available",
                            "description": "Not available", "language": "Not available"}

                if self.web_data:
                    content = document.page_content.encode("utf8", "strict").decode("utf-8").encode(
                        "ascii", "ignore").decode("utf-8", "strict").strip()
                    metadata = document.metadata
                elif type(document) == str:
                    content = document
                    if self.file_name is not None:
                        metadata["source"] = self.file_name
                else:
                    logging.info(f"Format not supported please fix")
                    return False
                content = re.split("[/\n]+", content)
                content = "\n ".join(content)
                temp = content.split("\n")
                doc_out = ""
                i = 0
                while i < len(temp):
                    t = temp[i].strip()
                    j = i + 1
                    while j < len(temp) and len(temp[j].strip()) == 0:
                        j += 1
                    doc_out += "\n " + t
                    i = j
                doc_out = doc_out.strip()
                content = doc_out.strip()

                # for few websites language is None
                metadata["language"] = "en_us"

                # using text splitter it's splitting documents into multiple documents
                output = self.text_splitter.create_documents([content], [metadata])

                # if page content or metadata is None milvus won't take input parameters
                for o in output:
                    temp = o.page_content.split("\n")
                    doc_out = ""
                    d = {}
                    if o is not None or o.page_content is not None:
                        d["content"] = o.page_content
                        d["id"] = self.get_unique_hash()
                        d["source"] = o.metadata.get("source", "Not available")
                        d["title"] = o.metadata.get("title", "Not available")
                        d["description"] = o.metadata.get("description", "Not available")
                        d["language"] = o.metadata.get("language", "Not available")
                        self.docs.append(d)
            logging.info("Successfully extracted documents for CosmoDb format")
        except Exception as ex:
            logging.error(f"Error while cleaning data: {ex}")
        return self.docs



# pre_test = PreProcessData()
# pre_test.load_pdf_data("sample.pdf")
# output = pre_test.cleaning_data()
# print(output)
#
