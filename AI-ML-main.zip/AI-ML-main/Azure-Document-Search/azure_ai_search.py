import logging

from logger_utils import Logger
from azure.search.documents import SearchClient
from openai_connection import OpenAIConnection
from azure.search.documents.models import Vector
from azure.core.credentials import AzureKeyCredential


logger = Logger()
logging = logger.get_logger()


class AzureVectorSearch:
    search_client = None

    def __init__(self, cog_search_endpoint, cog_search_key, index_name):
        try:
            self.cog_search_endpoint = cog_search_endpoint
            self.cog_search_key = cog_search_key
            self.index_name = index_name
            self.openAIConnection = OpenAIConnection()
            self.cog_search_cred = AzureKeyCredential(cog_search_key)
            logging.info("Successfully connected to Azure Key Credential")
        except Exception as ex:
            logging.error(f"Error initializing AzureVectorSearch: {ex}")

    def connect_client(self):
        """
        connected to Azure search client
        """
        status = False
        try:
            self.search_client = SearchClient(self.cog_search_endpoint, self.index_name, self.cog_search_cred)
            status = True
            logging.info("Successfully connected to Azure Search client")
            return status
        except Exception as ex:
            logging.error(f"Error connecting to Azure Search client: {ex}")
        return status

    def vector_search(self, query, k=1, fields=["content", "source"]):
        """
        searching for query on vector Azure search index
        """
        results = []
        try:
            if self.search_client is None:
                logging.info("No Azure Search client")
                return results
            output = self.openAIConnection.generate_embeddings(query)
            if len(output) == 0:
                logging.info("OpenAI embedding not found")
                return results
            query_vector = output[0].embedding
            results = self.search_client.search(search_text="",
                                                vector=Vector(value=query_vector, k=k, fields="vector"),
                                                select=fields)#["content","source"])
            results = list(results)
            logging.info("Successfully retrieved results from Azure Vector Search")
        except Exception as ex:
            logging.error(f"Error while query Azure Vector Search: {ex}")
        return results



cog_search_endpoint = "https://fissionchatbot.search.windows.net"
cog_search_key = "UJtIyFHBjBI0Fi64pxc5rqwWyZnE0OmZcebmFbfwUyAzSeAREcLc"
index_name = "fission-rag-vectorsearch"


azure_search_connect = AzureVectorSearch(cog_search_endpoint, cog_search_key, index_name)
azure_search_connect.connect_client()
query = "Who is Nishita Algubelli?"
output = azure_search_connect.vector_search(query)
for result in output:
    print(result)


