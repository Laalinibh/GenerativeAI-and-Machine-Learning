<H1>Document Search</H1>

Refence Link for Architecture: <a href="https://learn.microsoft.com/en-us/azure/developer/python/get-started-app-chat-template?tabs=github-codespaces#use-chat-app-to-get-answers-from-pdf-files">Azure Official Documentation</a><br>
Git refence Link: <a href="https://github.com/microsoft/AzureDataRetrievalAugmentedGenerationSamples/blob/main/Python/CosmosDB-NoSQL_CognitiveSearch/CosmosDB_CogSearch_AzureOpenAI_Tutorial.ipynb">Git Link</a><br><br>

Sorry Haven't shared requirements.txt
