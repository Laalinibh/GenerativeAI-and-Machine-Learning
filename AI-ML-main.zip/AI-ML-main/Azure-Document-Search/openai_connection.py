from openai import OpenAI
from logger_utils import Logger


import os
import time

from langchain.prompts import PromptTemplate
from tenacity import retry, wait_random_exponential, stop_after_attempt

logger = Logger()
logging = logger.get_logger()


class OpenAIConnection:
    openai_client = None
    model = None

    def __init__(self, embedding_model = "text-embedding-ada-002", model="gpt-4", max_tokens=4000, temperature=0, history="", messages=[]):
        """
        Please feel free to further update as per your requirements
        """
        try:
            self.openai_client = OpenAI()
            self.embedding_model = embedding_model
            self.model = model
            self.max_tokens = max_tokens
            self.temperature = temperature
            self.history = history
            self.messages = messages
            self.system_role = "system"
            self.user_role = "user"

            # Please feel free to add a method to update prompts as well.
            self.default_prompt = """You are an AI Conversational Question and Answering Chatbot. Please Answer to the Question using below Context and Coversation History.\nHistory: {history}\nContext: {context}\nQuestion: {question}
                    """
            self.openai_client = OpenAI()
            self.prompt = PromptTemplate(template=self.default_prompt,
                                         input_variables=["history", "context", "question"])
        except Exception as ex:
            logging.error(f"Error while initializing OpenAI client : {ex}")


    @retry(wait=wait_random_exponential(min=1, max=2), stop=stop_after_attempt(10))
    def generate_embeddings(self, text, embedding_model=None):
        '''
        Generate embeddings from array of string of text.
        This will be used to vectorize data and user input for interactions with Azure OpenAI.
        '''
        output = []
        try:
            if embedding_model is not None:
                self.embedding_model = embedding_model
            if self.openai_client is None:
                logging.info("OpenAI client not initialized")
                return output
            response = self.openai_client.embeddings.create(input=[text] , model=self.embedding_model)
            if len(response.data)>0:
                output = response.data
            time.sleep(0.5) # rest period to avoid rate limiting on AOAI for free tier
            logging.info("Successfully retrieved OpenAI embeddings")
        except Exception as ex:
            logging.error(f"Error while accessing OpenAI API retrieve_embeddings: {ex}")
        return output

    def get_model_output(self):
        """
        retrieving the model output
        """
        response = []
        try:
            output = self.openai_client.chat.completions.create(
                model=self.model,
                messages=self.messages,
                max_tokens=self.max_tokens,
                temperature=0, )
            response = list(output)
        except Exception as ex:
            print(f"Error while retrieving OpenAI output: {ex}")
        return response

    def clean_output(self, response):
        """
        cleaning the output and returning the 1st choice
        """
        try:
            for r in response:
                if r[0] == "choices":
                    arr = r[1]
                    for a in arr:
                        out = a.message.content
                        out = str(out)
                        if out.startswith('Answer:'):
                            out = out[8:]
                            out = out.strip()
                        return out
        except Exception as ex:
            print(f"Error while cleaning OpenAI output: {ex}")
        return response

    def add_messages(self, role, content):
        """
        adding it to messages
        """
        self.messages.append({"role": role, "content": content})

    def user_query(self, query="", content="", model=None, max_tokens=None, temperature=0, messages=[], history=None):
        """
        user_query = "Who is Surendra Mallampati?"
        """
        cleanedResponse = ""
        try:
            if query == "":
                print("Please enter query")
                return ""

            # updating if any of the parameters are modified
            if model is not None:
                self.model = model
            if max_tokens is not None:
                self.max_tokens = max_tokens
            if temperature is not None:
                self.temperature = temperature
            if messages:
                self.messages = messages
            if history is not None:
                self.history = history

            # creating promp
            prompt = self.prompt.format(history=self.history, context=content, question=query)
            prompt = prompt.strip()

            # adding it to user message
            self.add_messages(self.user_role, prompt)

            # retrieving output from OpenAI
            openai_response = self.get_model_output()

            # cleaning output
            cleanedResponse = self.clean_output(openai_response)
            cleanedResponse = cleanedResponse.strip()

            # adding response to messages
            self.add_messages(self.system_role, cleanedResponse)

            # updating history
            self.history += "User: " + query + "\n" + "Bot: " + cleanedResponse + "\n"
            return cleanedResponse
        except Exception as ex:
            print(f"Error while querying OpenAI: {ex}")
        return cleanedResponse

    def get_all_messages(self):
        """
        to cache all messages for future uses
        """
        return self.messages

    def get_history(self):
        """
        cache history or messages as per your requirements
        """
        return self.history

