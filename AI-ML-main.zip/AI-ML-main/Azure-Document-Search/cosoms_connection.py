from azure.cosmos import exceptions, CosmosClient, PartitionKey
from azure.core.exceptions import AzureError
from logger_utils import Logger

logger = Logger()
logging = logger.get_logger()


class CosmoConnection:
    db = None
    client = None
    container = None

    def __init__(self, endpoint, account_key, cosmos_connection_string):
        """
        required keys for connecting to cosmos database
        """
        self.endpoint = endpoint
        self.account_key = account_key
        self.cosmo_connection_string = cosmos_connection_string

    def connect_client(self):
        """
        Connecting to Cosmos DB
        """
        try:
            self.client = CosmosClient(self.endpoint, credential=self.account_key)
            logging.info("Successfully connected to CosmosDB client")
        except (Exception, AzureError, exceptions.CosmosClientTimeoutError) as ex:
            logging.error(f"Error connecting to Cosmos client: {ex}")

    def create_database(self, db_name):
        """
        creates a new database if the database does not exist
        """
        try:
            if self.client is None:
                logging.info("Cosmos database client not initialized")
                return
            self.db = self.client.create_database_if_not_exists(id=db_name)
            logging.info("Successfully created database")
            return True
        except (Exception, AzureError, exceptions.CosmosResourceExistsError) as ex:
            logging.error(f"Error while creating database: {ex}")
        return False

    def create_container(self, container_name):
        """
        creating a new container if the container does not exist
        """
        try:
            if self.db is None:
                logging.info("Cosmos db not initialized")
                return False
            partition_key_path = PartitionKey(path="/user")
            self.container = self.db.create_container_if_not_exists(
                id=container_name,
                partition_key=partition_key_path,
                offer_throughput=400,
            )
            logging.info("Successfully created container")
            return True
        except (Exception, AzureError, exceptions.CosmosResourceExistsError) as ex:
            logging.error(f"Error Creating container: {ex}")
        return False

    def connect_db(self, db_name):
        """
        connecting to the database
        """
        try:
            if self.client is None:
                logging.info("Cosmos client not initialized")
                return False
            self.db = self.client.get_database_client(db_name)
            logging.info("Successfully connected Cosmos db client")
            return True
        except (Exception, AzureError, exceptions.CosmosResourceExistsError) as ex:
            logging.error(f"Error connecting to container: {ex}")
        return False

    def connect_container(self, container_name):
        try:
            if self.db is None:
                logging.info("Cosmos db not initialized")
                return False
            self.container = self.db.get_container_client(container_name)
            logging.info("Successfully connected container")
            return True
        except (Exception, AzureError, exceptions.CosmosResourceExistsError) as ex:
            logging.error(f"Error connecting to container: {ex}")
        return False

    def get_databases(self):
        """Returns a list of databases"""
        output = []
        try:
            if self.db is None:
                logging.info("Cosmos db not initialized")
                return output
            output = [c['id'] for c in list(self.client.list_databases())]
            logging.info("Successfully retrieved db list")
            return output
        except (Exception, AzureError, exceptions.CosmosResourceExistsError) as ex:
            logging.error(f"Error connecting to container: {ex}")
        return output

    def get_containers(self):
        """
        returns list of container in database
        """
        output = []
        try:
            if self.container is None:
                logging.info("Cosmos container not initialized")
                return output
            output = [c['id'] for c in list(self.db.list_containers())]
            logging.info("Successfully retrieved container list")
            return output
        except (Exception, AzureError, exceptions.CosmosResourceExistsError) as ex:
            logging.error(f"Error retrieving list of container: {ex}")
        return output

    def insert_data(self, data):
        output = False
        try:
            if self.container is None:
                logging.info("Cosmos container not initialized")
                return output
            for d in data:
                self.container.create_item(body=d)
            logging.info("Successfully inserted data")
            output = True
            return output
        except (Exception, AzureError, exceptions.CosmosResourceExistsError) as ex:
            logging.error(f"Error inserting data into container: {ex}")
        return output

    def get_container_docs(self):
        output = []
        try:
            if self.container is None:
                logging.info("Cosmos container not initialized")
                return output
            output = list(self.container.read_all_items(max_item_count=10))
            logging.info("Successfully retrieved container list")
        except (Exception, AzureError, exceptions.CosmosResourceExistsError) as ex:
            logging.error(f"Error retrieving docs from container: {ex}")
        return output
