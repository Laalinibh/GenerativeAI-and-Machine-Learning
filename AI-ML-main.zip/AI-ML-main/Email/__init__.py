"""
Save the static information
"""
PASSWORD = "********"
SENDER = "test@fissionlabs.com"
SUBJECT = "test"
EMAIL_STMP = "smtp.gmail.com"
PORT = 587
RECEIVERS = ["test@fissionlabs.com"]
MESSAGE = """test"""

#sample
MESSAGE_SAMPLE = """Dear John,\n
I hope this email finds you well. I am reaching out to you with an exciting opportunity to join our company as a Senior Financial Analyst. After reviewing your impressive qualifications and experience, we believe you would be an excellent fit for our team.\n
With over 5 years of experience as a Senior Financial Analyst, you have demonstrated your expertise in various areas, including business intelligence, retention forecasts, statistical analysis, and monthly and quarterly reporting. Your ability to analyze complex financial data and present it effectively sets you apart from other candidates. Your strong oral and written communication skills further enhance your ability to collaborate with cross-functional teams and present financial insights to key stakeholders.\n
At our company, we strive for excellence and innovation in the financial analysis field. We value professionals who bring both technical expertise and a strategic mindset to the table. Your proven track record in developing accurate forecasts, conducting thorough statistical analysis, and delivering insightful presentations aligns perfectly with our goals.\n
In addition to your exceptional skills, we believe your passion for continuous learning and personal growth will contribute significantly to our team's success. We foster a culture of learning and provide ample opportunities for professional development, ensuring that our employees stay at the forefront of the industry.\n
As a Senior Financial Analyst at our company, you will be responsible for analyzing financial data, developing forecasts, and providing actionable insights to support strategic decision-making. You will collaborate with cross-functional teams, communicate financial results to stakeholders, and play a vital role in shaping the company's financial strategy.\n
We would love to discuss this opportunity further with you and learn more about how your experience and skills align with our organization. Please let us know your availability for a phone call or an in-person interview. We are flexible and can accommodate your schedule.\n
Thank you for considering this opportunity to join our team. We look forward to hearing from you and discussing how we can mutually benefit from working together. Should you have any questions or require further information, please do not hesitate to reach out to me directly at test@fissionlabs.com.\n

Calendar Invite: If you are interested please block the calendar for 30 minutes, so we can proceed further in the process. 
https://calendly.com/abc/intro-call-about-company 

Warm regards,
Test
Recruiter
FissionLabs
+1-(619)-000-0007
"""
