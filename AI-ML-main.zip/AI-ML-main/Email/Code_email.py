"""
connecting to email server and sending email

Enable Less Secure apps On from -> Mange your Google Account -> Security else the below code won't work or
Please Turn it on back post completion of your task.

Enable 2 step authentication and add App passwords and use it in code as password. 
More info about how to enable: https://exerror.com/smtplib-smtpauthenticationerror-username-and-password-not-accepted/
"""
import smtplib, ssl
from email.mime.text import MIMEText

## load email, password from configs, get rest from json input wrt service
## shared sample __init__ please feel free to update the required data wrt your local
from __init__ import PASSWORD, SENDER, SUBJECT, MESSAGE, RECEIVERS, EMAIL_STMP, PORT

class EmailConnection(object):
    """
    Connecting to an email and sending messages
    """

    server = None
    sender = None
    def __init__(self, web_server_url, port, sender, password, default_timeout=60):
        """
        connecting the appropriate server like gmail, hotmail, etc
        :param web_url:
        :param port wrt email service to communicate:
        :param default_timeout:
        """
        try:
            context = ssl.create_default_context()
            self.server = smtplib.SMTP(web_server_url, port=port, timeout=default_timeout)
            self.server.ehlo()
            self.server.starttls(context=context)
            self.server.login(sender, password)
            self.sender = sender
        except Exception as ex:
            print("Error while connecting or logging into to email server: {}".format(ex))
            self.server = None
        return None

    def send_message(self, all_args ):
        """
        sending a pojo(JSON OR DICT in python) which consists of all the required information
        :param all_args:
        :return:
        """
        try:
            # update constants in __init__.py
            if self.server is not None and "Message" in all_args and "Receivers" in all_args:
                msg = MIMEText(all_args["Message"])
                for key,val in all_args.items():
                    if key not in ["Message","Receivers"] :
                        msg[key] = val
                self.server.sendmail(self.sender, all_args["Receivers"], msg.as_string())
                print("Sucessfully sent message")
            else:
                print("Server is None or required args are missing wrt input json")

        except Exception as ex:
            print("Error while sending message: {}".format(ex))

    def close_connection(self):
        """
        closing the connection wrt the email server
        :return:
        """
        try:
            if self.server is not None:
                self.server.quit()
        except Exception as ex:
            print("Error while closing connection : {}".format(ex))

if __name__ == "__main__":

    ### load these from your config file wrt service or __init__.py in your local
    email_message = EmailConnection(EMAIL_STMP, PORT, SENDER, PASSWORD)

    # get this data from Json input wrt service or __init__.py wrt your local
    required_data = {"From":SENDER, "To": SENDER, "Receivers":RECEIVERS,
                     "Subject": SUBJECT, "Message": MESSAGE }

    #sending the message to required people
    email_message.send_message(required_data)

    #closing the email connection
    email_message.close_connection()

