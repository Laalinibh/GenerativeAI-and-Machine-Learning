# Azure QnA Maker Using Streamlit

This is only to test in your local, please feel free to fine-tune as per your requirements.


## Install required packages
Please install the required packages/libraries
- Run `pip install botbuilder-core`
- Run `pip install streamlit`
- Run `pip install azure`
- RUN `pip install azure-ai-language-questionanswering`
- RUN `ipp install azure-core` 
- Etc

## Running Streamlit 
- Run `streamlit run streamlit_cleaned_code.py`
- Please use the endpoint shared 

