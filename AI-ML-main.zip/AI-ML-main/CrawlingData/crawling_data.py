"""
This is just based on the data which we have wrt the specific use-case
please install the required packages and update the code wrt your requirements
"""

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

import time

class CrawlPage(object):
"""
This is just a generic template
Please feel free to make it asyncronous or use multi-processing to make it more fast
"""
    def __init__(self,):
        """
        installing if drivers are missing
        """
        try:
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service)
        except Exception as ex:
            print("Failed to install ChromeDriver: {}".format(ex))
            self.driver = None

    def url(self, url):
        """
        loading the url and extracting the data
        :param url:
        :return:
        """
        try:
            if self.driver is not None:
                self.driver.get(url)
                time.sleep(3)
            else:
                print("Selenium driver not installed, please check")
        except Exception as ex:
            print("Eror while retrieving url: {}".format(ex))

    def get_data(self, xpath):
        """
        # this is the xpath: "//h1[@class='abc-def']"
        # sample is a example header h1 with class name "abc-def"
        # you can use BeautifulSoup as well as per your familiarity.
        :param xpath:
        :return:
        """
        try:
            if self.driver is not None:
                
                output = self.driver.find_element(By.XPATH, xpath)
                return output
            else:
                print("Selenium driver not installed, please check")
        except Exception as ex:
            print("Error while retriving the")
        return None

    def close_conn(self):
        """
        close driver connection
        :return:
        """
        try:
            if self.driver is not None:
                self.driver.close()
        except Exception as ex:
            print("Error while closing connection: {}".format(ex))


if __name__ == "__main__":
    """
    This is just a sample working code 
    please modify it as per your use-case and requirement
    """
    crawler = CrawlPage()

    # update appropriate url
    url_crawl = "http://localhost:8080/"
    crawler.url(url_crawl)

    # update the xpath wrt the data you want to crawl from above url
    xpath = "//h1[@class='abc-def']"
    output = crawler.get_data(xpath)
    if output is not None:
        print(output.text)
    
    crawler.close_conn()
