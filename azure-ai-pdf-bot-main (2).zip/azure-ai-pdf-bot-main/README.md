# PDF Reader and OpenAI Q&A

This Streamlit app allows users to upload a PDF file, extract its content, and ask questions using OpenAI's question-answering capabilities.

## Features

- **PDF Upload**: Users can upload a PDF file to extract its text content.
- **OpenAI Integration**: Utilizes OpenAI's API to answer questions based on the uploaded PDF's context.
- **Conversation History**: Keeps a record of previous conversations between the user and the OpenAI chatbot.

## Installation

### Install the required packages:
```
pip install -r requirements.txt
```

### Set up the environment variables:
```
OPENAI_API_KEY=YOUR_OPENAI_API_KEY_HERE
```

## Usage
### Run the Streamlit app:

```
streamlit run app.py
```
