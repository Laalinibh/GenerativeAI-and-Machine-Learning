import hashlib
import random
import time
import json
import os
import random
import PyPDF2
import requests
import string
import sys
import logging
import os
from datetime import datetime
import uuid
from typing import List

# Third-party Imports
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from dotenv import dotenv_values
import streamlit as st

# Project-specific Imports
from langchain.callbacks import get_openai_callback
from langchain.chains import RetrievalQA
from langchain.chat_models import AzureChatOpenAI
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from langchain.prompts import PromptTemplate
from langchain.retrievers import AzureCognitiveSearchRetriever
from langchain.schema import HumanMessage
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores.azure_cosmos_db import (
    AzureCosmosDBVectorSearch,
    CosmosDBSimilarityType,
)
from langchain_community.vectorstores.azuresearch import AzureSearch
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from openai import AzureOpenAI

from config import (
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_EMBEDDING_MODEL,
    MODEL_DEPLOYMENT_NAME,
    SEARCH_ENDPOINT,
    SEARCH_KEY,
    SEARCH_INDEX_NAME,
    TEMPLATE,
)

# Create a log folder if it doesn't exist
log_folder = "logs"
os.makedirs(log_folder, exist_ok=True)

# Configure the logging settings
log_filename = os.path.join(log_folder, f"log_{datetime.now().strftime('%Y-%m-%d')}.txt")
logging.basicConfig(
    level=logging.INFO,  # Set the desired log level
    format='%(asctime)s [%(levelname)s] - %(message)s',
    handlers=[
        logging.FileHandler(log_filename),
        logging.StreamHandler(),  # Add this if you also want to log to the console
    ],
)



def get_or_generate_session_id():
    # Attempt to get the session ID from Streamlit's internal state
    session_id = st.session_state.get('session_id', None)

    # If the session ID is not present, generate a unique ID based on a timestamp and a random number
    if session_id is None:
        timestamp = int(time.time())  # Current Unix timestamp
        random_number = random.randint(1, 1000000)  # Random number between 1 and 1,000,000

        # Combine timestamp and random number to create a unique identifier
        session_id = hashlib.sha256(f"{timestamp}-{random_number}".encode()).hexdigest()

        # Save the session ID in st.session_state for persistence
        st.session_state.session_id = session_id

    return session_id


# Function to save the uploaded file to the 'data' folder
def save_uploaded_file(uploaded_file):
    """
    Saves the uploaded file to the 'data' folder.

    Parameters:
    - uploaded_file: Uploaded file object

    Returns:
    - file_path (str): Path where the file is saved
    """
    data_folder = 'data'
    if not os.path.exists(data_folder):
        os.makedirs(data_folder)
    
    file_path = os.path.join(data_folder, uploaded_file.name)
    with open(file_path, 'wb') as f:
        f.write(uploaded_file.getbuffer())
    
    return file_path


# Function to fetch previous conversation history (from session state)
def fetch_previous_history():
    """
    Fetches previous conversation history from session state.

    Returns:
    - conversation_history (list): List of previous conversation entries
    """
    return st.session_state.conversation_history

# Function to save new conversation entry to history list (in session state)
def save_to_history(question, bot_response):
    """
    Saves a new conversation entry to the history list in session state.

    Parameters:
    - question (str): User's question
    - bot_response (str): Chatbot's response to the user input
    """
    st.session_state.conversation_history.append((question, bot_response))
    # st.session_state.conversation_history.append({'user': user_input, 'bot': bot_response})
    
def generate_random_alphanumeric(length):
    """
    Generate a random alphanumeric string of a specified length.

    Parameters:
    - length (int): The length of the generated string.

    Returns:
    - str: The randomly generated alphanumeric string.
    """
    characters = string.ascii_letters + string.digits
    random_alphanumeric = ''.join(random.choice(characters) for _ in range(length))
    return random_alphanumeric

def generate_content_to_index(doc_id, user, session_id, raw_text, vector):
    """
    Generate content for indexing with the given parameters.

    Parameters:
    - doc_id (str): Identifier for the document.
    - user (str): Identifier for the user.
    - session_id (str): Identifier for the session.
    - raw_text (str): Raw text content to be indexed.
    - vector (str): Vector representation associated with the content.

    Returns:
    - dict: The content formatted for indexing.
    """
    content = {
        "id": generate_random_alphanumeric(6),
        "doc_id": doc_id,
        "userId": user,
        "sessionId": session_id,
        "Content": raw_text,
        "vector": vector,
        "@search.action": "upload"
    }
    return content
    

def index_to_ai_search(request_body):
    try:
        index_endpoint = "{0}/indexes/{1}/docs/index?api-version=2023-11-01".format(SEARCH_ENDPOINT, SEARCH_INDEX_NAME)

        logging.info(index_endpoint)

        headers = {
            'Content-Type': 'application/json',  # You can adjust the content type based on your needs
            'api-key': SEARCH_KEY  # Include any authorization header if required
        }

        response = requests.post(url=index_endpoint, json=request_body, headers=headers)
        if response.status_code == 200:
            logging.info("POST request successful!")
        else:
            logging.info(f"POST request failed with status code {response.status_code}")
            logging.info(f"Response content {response.text}")
        
    except Exception as e:
        st.exception(f"Issue in Indexing document data : {type(e).__name__} - {e}")
        
class CustomRetriever(BaseRetriever):

    endpoint:str
    index_name:str
    key:str
    filters:str
  
    def _get_relevant_documents(
        self, query: str, *, run_manager: CallbackManagerForRetrieverRun
    ) -> List[Document]:
        client = SearchClient(endpoint=self.endpoint, index_name=self.index_name, credential=AzureKeyCredential(self.key))
        response = client.search(search_text=query, filter=self.filters)  # Access client here #
        logging.info(f"query {query} filters {self.filters}")
        results = []
        while True:
            try:
                item = next(response)
                logging.info(f'from 1st block {item["doc_id"]}')
                # Assuming relevant content is in a field named "content"
                document = Document(
                    id=item['doc_id'],
                    page_content=item['Content'],  # Map relevant content to "content" attribute
                    #metadata={"title": item.get("title", ""), "url": item.get("url", "")}  # Add other metadata if needed
                )
                results.append(document)
            except StopIteration:
                break
                
        #If not results are found, then perform a search with empty query and filters        
        if not results:
            response = client.search(search_text="", filter=self.filters)
            logging.info('Into else response')
            while True:
                try:
                    item = next(response)
                    logging.info(f'from 2nd block {item["doc_id"]}')
                    document = Document(
                        id=item['doc_id'],
                        page_content=item['Content'],  # Map relevant content to "content" attribute
                        #metadata={"title": item.get("title", ""), "url": item.get("url", "")}  # Add other metadata if needed
                    )
                    results.append(document)
                except StopIteration:
                    break
        logging.info(f'Results size: {len(results)}')

        return results

def initialize_azure_openai_embeddings():
    """
    Initialize Azure OpenAI with the provided configuration.

    Returns:
    - AzureOpenAI: An instance of the AzureOpenAI class.
    """
    try:
        client = AzureOpenAI(
            api_key = AZURE_OPENAI_API_KEY,  
            api_version = "2023-05-15",
            azure_endpoint =AZURE_OPENAI_ENDPOINT
            )
        return client
    except Exception as e:
        st.exception(f"Issue in Initialize Azure OpenAI : {type(e).__name__} - {e}")


def process_pdf_file(file_path):
    """
    Process a PDF file using PyPDFLoader and CharacterTextSplitter.

    Parameters:
    - file_path (str): The file path to the PDF file.

    Returns:
    - list: A list of documents after processing.
    """
    try:
        loader = PyPDFLoader(file_path)
        documents = loader.load()

        text_splitter = CharacterTextSplitter(
            chunk_size=500,
            chunk_overlap=100,
            separator="\n"
        )
        processed_docs = text_splitter.split_documents(documents)

        return processed_docs

    except Exception as e:
        # Handle exceptions, log or raise as appropriate
        logging.error(f"Error processing PDF file: {e}", exc_info=True)
        st.exception(f"Issue in Processing the document : {type(e).__name__} - {e}")
        return []


def process_documents_for_embedding(docs, client, document_id, user_id, session_id):
    """
    Process a list of documents, generate embeddings, and create content for indexing.

    Parameters:
    - docs (list): List of documents to process.
    - client (AzureOpenAI): An instance of AzureOpenAI.
    - document_id (str): Identifier for the document being processed.
    - user_id (str): Identifier for the user associated with the document.
    - session_id (str): Identifier for the session or context of the document.

    Returns:
    - list: A list of content ready for indexing.
    """
    content = []

    for doc in docs:
        try:
            # Generate embeddings for the document using the Azure OpenAI service
            embedding_response = client.embeddings.create(
                input=doc.page_content,
                model="openai-embeddings"
            )

            # Generate content for indexing
            vectorstore_content = generate_content_to_index(
                document_id, user_id, session_id, doc.page_content, embedding_response.data[0].embedding
            )

            # Add the content to the list
            content.append(vectorstore_content)

        except Exception as e:
            # Handle exceptions, log or raise as appropriate
            logging.error(f"Issue in generating the embedding for the document {document_id}: {e}", exc_info=True)
            
            # Display an exception message in Streamlit (assuming Streamlit is used)
            st.exception(f"Issue in generating the embedding for the document {document_id}: {type(e).__name__} - {e}")

    return content

def process_documents_and_index(pdf_file_path, embeddings_instance, document_id, user_id, api_key):
    """
    Process a PDF file, generate embeddings, and index the content.

    Parameters:
    - pdf_file_path (str): Path to the PDF file.
    - embeddings_instance (AzureOpenAIEmbeddings): An instance of AzureOpenAIEmbeddings.
    - document_id (str): Identifier for the document.
    - user_id (str): Identifier for the user.
    - api_key (str): API key for indexing.

    Returns:
    - list: A list of content ready for indexing.
    """
    resulting_documents = process_pdf_file(pdf_file_path)
    content_for_indexing = process_documents_for_embedding(resulting_documents, embeddings_instance, document_id, user_id, api_key)
    return content_for_indexing


def initialize_azure_chat_openai(deployment_name, api_key, azure_endpoint, api_version="2023-08-01-preview", temperature=0):
    """
    Initialize AzureChatOpenAI with the provided configuration.

    Parameters:
    - deployment_name (str): Name of the deployment.
    - api_key (str): Azure OpenAI API key.
    - azure_endpoint (str): Azure OpenAI endpoint.
    - api_version (str): API version, default is "2023-08-01-preview".
    - temperature (float): Temperature parameter for AzureChatOpenAI, default is 0.

    Returns:
    - AzureChatOpenAI: An instance of AzureChatOpenAI.
    """
    try:
        llm = AzureChatOpenAI(
            deployment_name=deployment_name,
            temperature=temperature,
            api_key=api_key,
            azure_endpoint=azure_endpoint,
            api_version=api_version
        )
        return llm
    except Exception as e:
        st.exception(f"Issue in Initialize AzureChatOpenAI: {type(e).__name__} - {e}")

def create_qa_chain(llm, search_endpoint, search_index_name, search_key, filters, TEMPLATE):
    """
    Create a Retrieval QA chain using AzureChatOpenAI and CustomRetriever.

    Parameters:
    - llm (AzureChatOpenAI): An instance of AzureChatOpenAI.
    - search_endpoint (str): Endpoint for the search service.
    - search_index_name (str): Name of the search index.
    - search_key (str): API key for the search service.
    - TEMPLATE (str): Template for the PromptTemplate.

    Returns:
    - RetrievalQA: An instance of RetrievalQA.
    """
    QA_CHAIN_PROMPT = PromptTemplate.from_template(TEMPLATE)

    retriever = CustomRetriever(
        endpoint=search_endpoint,
        index_name=search_index_name,
        key=search_key,
        filters=filters
    )
    qa_chain = RetrievalQA.from_chain_type(
        llm,
        retriever=retriever,
        chain_type_kwargs={"prompt": QA_CHAIN_PROMPT},
        return_source_documents=True
    )

    return qa_chain


def create_and_configure_qa_chain(llm_instance, filters, TEMPLATE):
    """
    Create and configure a QA chain for retrieval.

    Parameters:
    - llm_instance (AzureChatOpenAI): An instance of AzureChatOpenAI.
    - TEMPLATE (str): Template for the PromptTemplate.

    Returns:
    - RetrievalQA: An instance of RetrievalQA.
    """
    qa_chain_instance = create_qa_chain(
        llm_instance,
        SEARCH_ENDPOINT,
        SEARCH_INDEX_NAME,
        SEARCH_KEY,
        filters,
        TEMPLATE
    )
    return qa_chain_instance

def initialize_and_process(pdf_file_path, document_id, user_id, session_id):
    """
    Initialize Azure OpenAI Embeddings, process PDF, generate embeddings, index content,
    and configure QA chain for retrieval.

    Parameters:
    - MODEL_DEPLOYMENT_NAME (str): Name of the deployment.
    - pdf_file_path (str): Path to the PDF file.
    - document_id (str): Identifier for the document.
    - user_id (str): Identifier for the user.
    - session_id (str): Identifier for the session.
    - TEMPLATE (str): Template for the PromptTemplate.

    Returns:
    - tuple: Instances of AzureOpenAIEmbeddings, RetrievalQA, and content for indexing.
    """
    # Initialize Azure OpenAI Embeddings
    embeddings_instance = initialize_azure_openai_embeddings()

    # Initialize Azure Chat OpenAI
    llm_instance = initialize_azure_chat_openai(MODEL_DEPLOYMENT_NAME, AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT)

    # Process PDF, generate embeddings, and index content
    content_for_indexing = process_documents_and_index(pdf_file_path, embeddings_instance, document_id, user_id, session_id)

    # Index content to AI search service
    index_to_ai_search({"value": content_for_indexing})

    # Create and configure QA chain for retrieval
    qa_chain_instance = create_and_configure_qa_chain(llm_instance, f"sessionId eq '{session_id}'",TEMPLATE)

    return embeddings_instance, qa_chain_instance, content_for_indexing
